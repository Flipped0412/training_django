# SSAFY 14기 Django 라이브 자료

| 진행일 | 주제            |
| ------ | --------------- |
| 09/18 | Intro & Design Pattern |
| 09/19 | Template & URLs |
| 09/23 | Model |
| 09/24 | ORM |
| 09/25 | ORM with view |
| 09/29 | Form |
| 09/30 | Authentication system 01 |
| 10/1 (오전) | Authentication system 02 |
| 10/1 (오후) | Authentication system 03 |
| 10/10 | Static Files |
| 11/12 | Django REST Framework 01 |
| 11/13 | Django REST Framework 02 |

